<?php

declare(strict_types=1);

namespace Intervention\Image\Analyzers;

use Intervention\Image\Drivers\SpecializableAnalyzer;

class ProfileAnalyzer extends SpecializableAnalyzer
{
}
