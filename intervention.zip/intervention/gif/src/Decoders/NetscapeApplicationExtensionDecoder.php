<?php

declare(strict_types=1);

namespace Intervention\Gif\Decoders;

class NetscapeApplicationExtensionDecoder extends ApplicationExtensionDecoder
{
}
